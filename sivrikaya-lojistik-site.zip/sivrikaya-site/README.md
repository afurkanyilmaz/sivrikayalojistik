# Sivrikaya Lojistik - Landing Page

## GitHub'a yükleme
1. Bu zip'i aç, içindeki `index.html` dosyasını al.
2. https://github.com/afurkanyilmaz/sivrikayalojistik adresine git.
3. "Add file" -> "Upload files" -> `index.html` dosyasını sürükle-bırak yap.
4. Alt kısımda "Commit changes" butonuna bas.

## 404 hatasını çözmek (GitHub Pages aktif etme)
Dosya repoda görünse bile, GitHub Pages'i AYRICA aktif etmen gerekiyor, yoksa site adresi 404 verir:

1. Repo sayfasında üstteki **Settings** sekmesine gir.
2. Sol menüden **Pages**'e tıkla.
3. "Build and deployment" altında **Source: Deploy from a branch** seçili olsun.
4. **Branch** kısmından **main** ve klasör olarak **/ (root)** seç, **Save** butonuna bas.
5. 1-2 dakika bekle, sayfa otomatik build olacak.
6. Site adresin: `https://afurkanyilmaz.github.io/sivrikayalojistik/`

Not: Dosyanın adı `index.html` olmak zorunda, yoksa GitHub Pages anasayfa olarak onu açmaz.
